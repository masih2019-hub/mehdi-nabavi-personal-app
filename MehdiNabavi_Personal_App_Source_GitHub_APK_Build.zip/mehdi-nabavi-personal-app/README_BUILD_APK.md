# اپ شخصی سیدمهدی نبوی — ProjectPro

این پکیج شامل دو خروجی است:

1. `www/` نسخه وب/PWA آماده تست روی موبایل
2. `android-app/` سورس اندروید WebView آماده Build برای گرفتن APK

## اطلاعات استفاده‌شده
- نام: سیدمهدی نبوی
- تخصص: SEO، AEO، AI، WordPress و WooCommerce SEO
- سایت: https://projectpro.ir
- تماس و واتساپ: 09119152274
- ایمیل: nabavimahdi68@gmail.com
- موقعیت: آمل، مازندران، ایران

## ساخت APK در Android Studio
1. Android Studio را باز کن.
2. گزینه Open را بزن.
3. پوشه `android-app` را انتخاب کن.
4. اجازه بده Gradle Sync کامل شود.
5. از مسیر زیر APK بگیر:
   `Build > Build Bundle(s) / APK(s) > Build APK(s)`
6. فایل نهایی معمولاً در این مسیر ساخته می‌شود:
   `android-app/app/build/outputs/apk/debug/app-debug.apk`

## ساخت APK با دستور ترمینال
داخل پوشه `android-app` اجرا کن:

```bash
gradle assembleDebug
```

یا اگر Gradle Wrapper اضافه کردی:

```bash
./gradlew assembleDebug
```

## نکته طراحی
رنگ‌بندی بر اساس اعتمادسازی و فروش طراحی شده:
- سرمه‌ای عمیق: اعتماد، تخصص، ثبات
- سبز زمردی: رشد، اقدام، تماس
- طلایی شامپاینی: پرستیژ و ارزش
- کرم روشن: حس آرام، حرفه‌ای و انسانی

فونت در CSS روی `Vazirmatn` تنظیم شده و در صورت نصب/لود شدن فونت، اپ با همان فونت نمایش داده می‌شود.
