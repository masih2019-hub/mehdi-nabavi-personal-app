# ساخت APK با یک کلیک در GitHub Actions

1. این پوشه را در یک ریپازیتوری GitHub آپلود کن.
2. وارد تب **Actions** شو.
3. Workflow با نام **Build Android APK** را انتخاب کن.
4. روی **Run workflow** بزن.
5. بعد از اتمام Build، از بخش **Artifacts** فایل APK را دانلود کن.

مسیر خروجی در پروژه:
`android-app/app/build/outputs/apk/debug/app-debug.apk`

اگر با Android Studio می‌سازی:
`android-app` را باز کن و بزن:
`Build > Build Bundle(s) / APK(s) > Build APK(s)`
